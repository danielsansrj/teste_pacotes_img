# package_name

Description. 
The package processamento-imagens is used to:
	- Plotar imagem

	- 

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install processamento-imagens
```

## Usage

```python
from processamento-imagens.processing import basicao
basicao.plot()
```

## Author
Daniel Sans

## License
[MIT](https://choosealicense.com/licenses/mit/)