# package_name

Description. 
The package 22-processamento-imagens is used to:

	- Plotar imagem

	- 

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install processsss
```

## Usage

```python
from processsss.processing import plot
basicao.plot()
```

## Author
Daniel Sans

## License
[MIT](https://choosealicense.com/licenses/mit/)